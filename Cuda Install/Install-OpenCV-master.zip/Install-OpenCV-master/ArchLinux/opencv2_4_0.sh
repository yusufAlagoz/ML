pacman -S python2-numpy
pacman -S opencv 2.4.0_a-4
